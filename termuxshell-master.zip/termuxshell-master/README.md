# termuxshell
beautify your termux app with this shell 😍.

